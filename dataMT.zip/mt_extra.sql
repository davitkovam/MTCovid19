
--
-- Indexes for dumped tables
--

--
-- Indexes for table nijz
--
ALTER TABLE nijz
  ADD PRIMARY KEY (Data);
