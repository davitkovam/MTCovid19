
-- --------------------------------------------------------

--
-- Table structure for table population
--

CREATE TABLE population (
  Regija varchar(21) CHARACTER SET utf8 DEFAULT NULL,
  Prebivalstvo int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table population
--

INSERT INTO population (Regija, Prebivalstvo) VALUES
('SLOVENIJA', 2066880),
('Pomurska', 114776),
('Podravska', 322058),
('Koroska', 70550),
('Savinjska', 254760),
('Zasavska', 57061),
('Posavska', 75359),
('Jugovzhodna_Slovenija', 142819),
('Osrednjeslovenska', 542306),
('Gorenjska', 203636),
('Primorsko_notranjska', 52334),
('Goriska', 117260),
('Obalno_kraska', 113961);
